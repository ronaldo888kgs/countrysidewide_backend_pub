<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Section extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'unit_id',
        'user_id',
        'workspace_id',
        'order_in_project',
        'category_id'
    ];

    public function subsections(): HasMany
    {
        return $this->hasMany(SubSection::class);
    }

    public function unit (): BelongsTo
    {
        return $this->belongsTo(Unit::class, 'unit_id', 'id');
    }
    public function workspace(): BelongsTo
    {
        return $this->belongsTo(Workspace::class);
    }
}
