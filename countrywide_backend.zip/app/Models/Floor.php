<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\belongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Floor extends Model
{
    use HasFactory;

    protected $fillable = [
        'name', 'project_id', 'user_id', 'item_order', 'workspace_id'
    ];


    public function project(): belongsTo
    {
        return $this->belongsTo(Project::class ,'project_id', 'id');
    }

    public function units(): HasMany
    {
        return $this->hasMany(Unit::class);
    }
    public function workspace(): BelongsTo
    {
        return $this->belongsTo(Workspace::class);
    }
}
