<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class SubSection extends Model
{
    use HasFactory;

    
    protected $fillable = [
        'name',
        'category_id',
        'user_id',
        'section_id',
        'status',
        'completion_status', 
        'workspace_id',
        'attachments',
        'sub_category_id'
    ];


    public function section(): BelongsTo
    {
        return $this->belongsTo(Section::class);
    }

    public function mediafiles(): HasMany
    {
        return $this->hasMany(Media::class,  'model_id');
    }

    public function comments(): HasMany
    {
        return $this->hasMany(Comment::class,  'subsection_id');
    }


    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function workspace(): BelongsTo
    {
        return $this->belongsTo(Workspace::class);
    }
}
