<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\belongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class History extends Model
{
    use HasFactory;
    protected $fillable = [
        'item_name', 'project_id', 'model_id', 'status_history', 'user_name', 'workspace_id'
    ];
    
    public function workspace(): BelongsTo
    {
        return $this->belongsTo(Workspace::class);
    }
}
