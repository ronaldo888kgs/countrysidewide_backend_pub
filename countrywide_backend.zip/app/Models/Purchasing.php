<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Purchasing extends Model
{
    use HasFactory;

    
    protected $fillable = [
        'submittals_id',
        'workspace_id',
        'user_id',
        'project_id',
        'area',
        'order_status',
        'net_qty',
        'waste',
        'attic_stock',
        'gross_qty',
        'remaining',
        'order_qty',
        'order_number',
        'payment_status',
        'lead_time',
        'notes',
        'tag',
        'supplier',
        'unit',
        'desc'
    ];

    public function submittal()
    {
        return $this->hasOne(Submittal::class, 'id');
    }

    public function mediafiles(): HasMany
    {
        return $this->hasMany(Media::class,  'model_id');
    }

}
