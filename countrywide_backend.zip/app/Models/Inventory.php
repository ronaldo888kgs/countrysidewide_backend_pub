<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Inventory extends Model
{
    use HasFactory;

    
    protected $fillable = [
        'submittals_id',
        'workspace_id',
        'user_id',
        'project_id',
        'order_status',
        'status',
        'ordered_qty',
        'received_qty',
        'location',
        'notes',
        'tag',
        'supplier',
        'unit',
        'desc'
    ];

    public function submittal()
    {
        return $this->hasOne(Submittal::class, 'id');
    }

    public function mediafiles(): HasMany
    {
        return $this->hasMany(Media::class,  'model_id');
    }


}
