<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ShowDrawing extends Model
{
    use HasFactory;

     protected $fillable = [
        'name',
        'title',
        'project_id',
        'workspace_id',
        'created_by',
        'url',
        'description',
        'tag',
        'version_set_id'
    ];
}
