<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;


class InvitedList extends Model
{
    use HasFactory;

    protected $fillable = [
        'invitee', 'inviter', 'project_id'
    ];


    public function project():  BelongsTo
    {
        // return $this->belongsTo(Project::class, 'project_id', 'id');
        return $this->belongsTo(Project::class,  'project_id', 'id');
    }


    public function inviter() : BelongsTo
    {
        return $this->belongsTo(User::class,  'inviter', 'id');
    }

    public function invitee() : BelongsTo
    {
        return $this->belongsTo(User::class,  'invitee', 'id');
    }

}
