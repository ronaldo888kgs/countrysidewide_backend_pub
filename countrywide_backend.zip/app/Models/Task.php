<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Task extends Model
{
    use HasFactory;

    protected $fillable = [
        'description',
        'due_date',
        'project_id',
        'status',
        'user_id',
        'attachment',
        'priority',
        'user', 
        'workspace_id',
        'number',
    ];


    public function mediafiles(): HasMany
    {
        return $this->hasMany(Media::class,  'model_id');
    }

    public function assignment(): HasMany
    {
        return $this->hasMany(TaskAssigment::class,  'task_id');
    }

    public function workspace(): BelongsTo
    {
        return $this->belongsTo(Workspace::class);
    }
}
