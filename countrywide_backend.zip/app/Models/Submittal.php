<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Submittal extends Model
{
    use HasFactory;

    protected $fillable = [
        'desc',
        'name', 
        'project_id', 
        'status', 
        'supplier', 
        'units',
        'attachment_url',
        'workspace_id',
        'user_id',
    ];

    
    public function mediafiles(): HasMany
    {
        return $this->hasMany(Media::class,  'model_id');
    }
}
