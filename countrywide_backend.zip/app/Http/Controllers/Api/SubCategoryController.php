<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Web\Controller;
use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\SubCategory;
use App\Models\Section;
use App\Models\SubSection;
use Illuminate\Support\Facades\Validator;

class SubCategoryController extends Controller
{
    //addSubCategory

    public function getAllCategories(Request $request)
    {
        $res = null;
        if($request->user()->user_type == "Super")
            $res = SubCategory::all();
        else
            $res = SubCategory::where('workspace_id', $request->user()->workspace_id)->get();
        return response()->json([
            'status' => 200,
            'sections' => $res
        ], 200);
    }

    

    public function addSubCategory(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'name' => 'required',
            'category_id' => 'required',
            'sectionName'=>'required',
        ]);
        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        SubCategory::create([
            'name' => $request->name, 
            'category_id' => $request->category_id, 
            'workspace_id' => $request->user()->workspace_id,
            'user_id' => $request->user()->id]);

        $res = Category::with('SubCategory')->where('workspace_id' , $request->user()->workspace_id)->get();

        $allSections = Section::where('name', $request->sectionName)->where('workspace_id', $request->user()->workspace_id)->get();

        foreach($allSections as $section)
        {
            SubSection::create([
                'name'=>  $request->name,
                'user_id' => $request->user()->id,
                'section_id' => $section->id,
                'status' => -1,
                'workspace_id' => $request->user()->workspace_id,
                'completion_status' => 1,
                'attachments', 0
            ]);
        }


        return response()->json([
            'status' => 200,
            'message' => 'success to add new category',
            'sections' => $res,
        ], 200);
    }


    public function deleteSubCategory(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'subcategory_id' => 'required',
            'sectionName'=>'required',
        ]);
        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }
        $res = SubCategory::where('id', $request->subcategory_id)->where('workspace_id' , $request->user()->workspace_id,)->first();
        if(!isset($res))
        {
            return response()->json([
                'status' => false,
                'message' => 'Not existed id',
            ], 500);
        }

        $subCategoryName = $res->name;
        $res->delete();

        $allSections = Section::where('sub_category_id', $request->subcategory_id)->get();

        foreach($allSections as $section)
        {
            $allSubSections = SubSection::where('section_id', $section->id)
            ->where('workspace_id', $request->user()->workspace_id)
            ->where('name', $subCategoryName)->get(); 
            foreach($allSubSections as $subSection)
            {
                $subSection->delete();
            }
        }


        return response()->json([
            'status' => 200,
            'message' => 'update category updated',
        ]);

    }

    public function updateSubCategory(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'subcategory_id' => 'required',
            'name' => 'required',
            'sectionName' => 'required',
            'category_id' => 'required'

        ]);
        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        

        $res = SubCategory::where('id', $request->subcategory_id)->where('workspace_id' , $request->user()->workspace_id,)->first();
        if(!isset($res))
        {
            return response()->json([
                'status' => false,
                'message' => 'Not existed id',
            ], 500);
        }

        $resOld = SubCategory::where('name', $request->name)->where('category_id' , $request->category_id,)->first();
        if(isset($resOld))
        {
            return response()->json([
                'status' => false,
                'message' => 'Already Existed name',
            ], 500);
        }


        $newSubSectionName = $request->name;
        $oldSubSectionName = $res->name;


        $res->name = $request->name;
        $res->save();

        $allSubSections = SubSection::where('sub_category_id', $res->id)
           ->get();
        foreach($allSubSections as $subSection)
        {
            $subSection->name = $newSubSectionName;
            $subSection->save();
        }

        return response()->json([
            'status' => 200,
            'message' => 'update category updated',
        ]);

    }
}
