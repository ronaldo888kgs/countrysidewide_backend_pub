<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Web\Controller;
use Illuminate\Http\Request;
use App\Models\Submittal;
use Illuminate\Support\Facades\Validator;

class SubmittalController extends Controller
{
    //


    public function getSubmittals(Request $request)
    {
        $project_id = $request->get('project_id');
        $res = Submittal::with(['mediafiles' => function($query){
            $query->where('type', 'Submittal')->get();
        }])->where('project_id', $project_id)->get();
        return response()->json([
            'status' => 200,
            'submittals' => $res,
        ], 200); 
    }

    public function addNewSubmittal(Request $request)
    {
        
        Submittal::create([
            'desc' => isset($request->desc) ? $request->desc : '',
            'name' => isset($request->name) ? $request->name : '',
            'project_id'=> $request->project_id,
            'status'=> isset($request->status) ? $request->status : '',
            'supplier'=> isset($request->supplier) ? $request->supplier : '',
            'units'=> isset($request->units) ? $request->units : '',
            'notes'=> isset($request->notes) ? $request->notes : '',
            'attachment_url' => "",
            'workspace_id' => $request->user()->workspace_id,
            'user_id' => $request->user()->id,
        ]);

        return response()->json([
            'status' => 200,
            'message' => 'success to add new submittal',
        ], 200);


    }

    public function updateSubmittal(Request $request)
    {
        
        $obj = Submittal::where('id', $request->submittal_id)->first();

        if(!isset($obj))
        {
            return response()->json([
                'status' => 500,
                'message' => 'Not found Submittal by id',
            ], 200);
        }

        $obj->desc  = isset($request->desc) ? $request->desc : '';
        $obj->name  = isset($request->name) ? $request->name : '';
        $obj->project_id = $request->project_id;
        $obj->status = isset($request->status) ? $request->status : '';
        $obj->supplier = isset($request->supplier) ? $request->supplier : '';
        $obj->units = isset($request->units) ? $request->units : '';
        $obj->notes = isset($request->notes) ? $request->notes : '';
        $obj->save();

        return response()->json([
            'status' => 200,
            'message' => 'success to update submittal',
        ], 200);
    }

    public function deleteSubmittal(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'submittal_id' => 'required',
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        $obj = Submittal::where('id', $request->submittal_id)->first();

        if(!isset($obj))
        {
            return response()->json([
                'status' => 500,
                'message' => 'Not found Submittal by id',
            ], 200);
        }

        $obj->delete();

        return response()->json([
            'status' => 200,
            'message' => 'success to delete submittal',
        ], 200);
    }
}
