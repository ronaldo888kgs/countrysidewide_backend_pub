<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Web\Controller;
use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\Section;
use App\Models\SubSection;
use App\Models\Unit;
use App\Models\Floor;
use App\Models\Project;
use App\Models\SubCategory;
use App\Models\Workspace;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class CategoryController extends Controller
{
    //
    public function getAllCategories(Request $request)
    {
        $category_id = $request->get('id');
        if(isset($category_id))
        {
            $res = Category::where('id', $category_id)->where('workspace_id', $request->user()->workspace_id)->with('SubCategory')->get();
            return response()->json([
                'status' => 200,
                'sections' => $res
            ], 200);
        }

        $projectId = $request->get('projectId');
        $res = null;
        if(isset($projectId))
        {
            $res = Category::with('SubCategory')->where('project_id', $projectId)->get();
        }else{
            if($request->user()->user_type == "Super")
                $res = Category::with('SubCategory')->get();
            else
                $res = Category::with('SubCategory')->where('workspace_id', $request->user()->workspace_id)->get();
        }
        
        
        return response()->json([
            'status' => 200,
            'sections' => $res
        ], 200);
    }

    public function addNewCategoryForProject(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'name' => 'required',
            'subSections' => 'required',
            'project_id' => 'required'
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        $old = Category::where('name', '=', $request->name)->where('project_id', $request->project_id)->first();

        if($old)
        {
            return response()->json([
                'status' => false,
                'message' => 'Name of the new category has been already existed',
                'errors' => 'Name of the new category has been already existed'
            ], 200);
        }

        $c = Category::create([
            'name' => $request->name, 
            'user_id' => $request->user()->id, 
            'workspace_id' => $request->user()->workspace_id, 
            'project_id' => $request->project_id]);

        for($k = 0 ; $k < count($request->subSections) ; $k++)
        {
            $subname = $request->subSections[$k];
            SubCategory::create([
                'name' => $subname, 
                'category_id' => $c->id, 
                'user_id' => $request->user()->id, 
                'workspace_id' => $request->user()->workspace_id]);
        }
        return response()->json([
            'status' => 200,
            'message' => 'success to add new category',
        ], 200);


    }

    public function addCategory(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'name' => 'required',
            'projectId' => 'required',
        ]);
        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        $old = Category::where('name', '=', $request->name)->where('project_id', $request->projectId)->where('workspace_id', $request->user()->workspace_id)->first();

        if($old)
        {
            return response()->json([
                'status' => false,
                'message' => 'Name of the new category has been already existed',
                'errors' => 'Name of the new category has been already existed'
            ], 200);
        }


        Category::create(['name' => $request->name, 'user_id' => $request->user()->id, 'project_id' => $request->projectId, 'workspace_id' => $request->user()->workspace_id]);
        return response()->json([
            'status' => 200,
            'message' => 'success to add new category',
        ], 200);
    }


    public function deleteCategory(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'category_id' => 'required',
        ]);
        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }
        $res = Category::where('id', $request->category_id)->first();
        if(!isset($res))
        {
            return response()->json([
                'status' => false,
                'message' => 'Not existed id',
            ], 500);
        }
        

        $allSections = Section::where('category_id', $request->category_id)->get();
        foreach($allSections as $section)
        {
            $section->delete();
        }

        $res->delete();



        return response()->json([
            'status' => 200,
            'message' => 'update category updated',
        ]);

    }

    public function resortExistedSections(Request $request)
    {
        $workspaces = Workspace::get();
        foreach($workspaces as $w)
        {
            $projects = Project::where('workspace_id', $w->id)->get();
            foreach($projects as $p)
            {
                $categories = Category::where('workspace_id', $w->id)->where('project_id', $p->id)->get();


                $units = DB::table('units')
                ->leftJoin('floors', 'floor_id', '=', 'floors.id')
                ->where('floors.project_id', $p->id)
                ->select('units.id as unit_id')->get();

                foreach($units as $u)
                {
                    $sections = DB::table('sections')
                    ->leftJoin('units', 'unit_id', '=', 'units.id')
                    ->where('units.id', $u->unit_id)
                    ->select('sections.id as section_id', 'sections.name as section_name', 'sections.*')
                    ->get();

                    foreach($sections as $s1)
                    {
                        foreach($categories as $c)
                        {
                            $s2 = Section::where('id', $s1->id)->where('name', $c->name)->first();
                            if(isset($s2))
                            {
                                $s2->category_id = $c->id;
                                $s2->save();

                                $subsections = SubSection::where('section_id', $s2->id)->get();
                                foreach($subsections as $ss1)
                                {
                                    $subcate = SubCategory::where('name', $ss1->name)->where('category_id', $c->id)->first();
                                    $ss1->sub_category_id = $subcate->id;
                                    $ss1->save();
                                }
                            }

                            
                        }
                        
                    }
                }

                
            }
        }
    }


    public function resortCategories(Request $request)
    {
        $workspaces = Workspace::get();
        foreach($workspaces as $w)
        {
            $projects = Project::where('workspace_id', $w->id)->get();
            $categories = Category::where('workspace_id', $w->id)->whereNull('project_id')->get();
            foreach($categories as $c)
            {
                $subcats = SubCategory::where('category_id', $c->id)->get();
                foreach($projects as $p)
                {
                    $cc = Category::create([
                        'name' => $c->name, 
                        'user_id' => $p->user_id, 
                        'workspace_id' => $w->id,
                        'project_id' => $p->id]);
                    
                    foreach($subcats as $s)
                    {
                        SubCategory::create([
                            'name' => $s->name, 
                            'category_id' => $cc->id, 
                            'user_id' => $p->user_id, 
                            'workspace_id' => $w->id
                        ]);
                    }

                }
            }
        }
    }

    public function updateCategory(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'category_id' => 'required',
            'name' => 'required',

        ]);
        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        

        $res = Category::where('id', $request->category_id)->first();
        if(!isset($res))
        {
            return response()->json([
                'status' => false,
                'message' => 'Not existed id',
            ], 500);
        }

        $resOld = Category::where('name', $request->name)->where('project_id', $res->project_id)->where('workspace_id', $request->user()->workspace_id)->first();

        if(isset($resOld))
        {
            return response()->json([
                'status' => false,
                'message' => 'Exsting name',
            ], 500);
        }

        $oldName = $res->name;
        $newName = $request->name;
        $res->name = $request->name;
        $res->save();

        //change all project;
        $allSections = Section::where('category_id', $resOld->id)->get();
        foreach($allSections as $section)
        {
            $section->name = $newName;
            $section->save();
        }

        return response()->json([
            'status' => 200,
            'message' => 'update category updated',
        ]);

    }
}
