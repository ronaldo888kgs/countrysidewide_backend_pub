<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Web\Controller;
use Illuminate\Http\Request;

use App\Models\User;
use App\Models\Contractor;
// use App\Models\Role;
use App\Models\Floor;
use App\Models\Section;
use App\Models\SubSection;
use App\Models\Project;
use App\Models\Unit;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class UserController extends Controller
{
    //

    public function resetPwd(Request $request)
    {
        
    }

    public function getAllUsers_for_inviting(Request $request)
    {
        $workspaceId = $request->user()->workspace_id;

        if($workspaceId === 0)
            return response()->json([
                'status' => false,
                'message' => 'You have no any workspaces to management, please ask to super user',
                'errors' => $validateUser->errors()
            ], 401);
        $user2 = User::where('workspace_id', $workspaceId)->where('id', '!=', $request->user()->id)->get();
        return response()->json([
            'status' => 200,
            'users' => $user2
        ], 200);
    }

    public function getAllUsers(Request $request)
    {
        if($request->user()->user_type == "Super")
        {
            $workspaceId = $request->get('workspace_id');
            if(isset($workspaceId))
            {
                $user2 = User::with(['workspace'])->where('workspace_id', $workspaceId)->get();
                return response()->json([
                    'status' => 200,
                    'users' => $user2
                ], 200);
            }
            $user2 = User::with(['workspace'])->get();
            return response()->json([
                'status' => 200,
                'users' => $user2
            ], 200);
        }
        return $this->getAllUsersByAdmin($request->user());
    }

    private function getAllUsersByAdmin($user)
    {
        $workspaceId = $user->workspace_id;

        if($workspaceId === 0)
            return response()->json([
                'status' => false,
                'message' => 'You have no any workspaces to management, please ask to super user',
                'errors' => $validateUser->errors()
            ], 401);
        $user2 = User::where('workspace_id', $workspaceId)->get();
        return response()->json([
            'status' => 200,
            'users' => $user2
        ], 200);
    }


    public function getUserDetails(Request $request)
    {
        // dd($request->get('id'));
         // return all address.
         $userid = $request->get('id');
         $user2 = User::where('id', $userid)->first();
         
        if($request->user()->user_type != "Super" && $request->user()->workspace_id != $user2->workspace_id)
        {
            return response()->json([
                'status' => false,
                'message' => 'No perimission for this user',
            ], 401);
        }
 
         return response()->json([
             'status' => 200,
             'user' => $user2
         ], 200); 
    }

    public function updateUser(Request $request)
    {

        // if($request->user()->user_type != "Admin") // only superuser
        // {
        //     return response()->json([
        //         'status' => false,
        //         'message' => 'No permission',
        //         'errors' => $validateUser->errors()
        //     ], 401);
        // }

        $validateUser = Validator::make($request->all(), 
        [
            'usertype' => 'required',
            'id' => 'required',
            'email' => 'required|email',
            'name' => 'required',
            'password' => 'required',
            
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 401);
        }

        $user2 = User::where('id', $request->id)->first();

        if($request->user()->user_type != "Super" && $request->user()->workspace_id != $user2->workspace_id)
        {
            return response()->json([
                'status' => false,
                'message' => 'No perimission for this user',
            ], 401);
        }

        $user2->name = $request->name;
        $user2->email = $request->email;
        $user2->user_type = $request->usertype;
        $user2->password = Hash::make($request->password);
        $user2->save();


        return response()->json([
            'status' => 200,
            'message' => 'update customer updated',
            'errors' => $validateUser->errors()
        ]);


    }

    public function updateItem(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'type' => 'required',
            'itemId' => 'required',
            'name' => 'required',
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }


        if($request->type == "floor") 
        {
            $floor = Floor::where('id', $request->itemId)->first();

            if($request->user()->user_type != "Super" && $request->user()->workspace_id != $floor->workspace_id)
            {
                return response()->json([
                    'status' => false,
                    'message' => 'No perimission for this user',
                ], 401);
            }

            if($floor)
            {
                $floor->name = $request->name;
                $floor->save();
            }
        } else if($request->type == "unit") {
            $unit = Unit::where('id', $request->itemId)->first();


            if($request->user()->user_type != "Super" && $request->user()->workspace_id != $unit->workspace_id)
            {
                return response()->json([
                    'status' => false,
                    'message' => 'No perimission for this user',
                ], 401);
            }


            if($unit)
            {
                $unit->name = $request->name;$unit->save();
            }
        }

        return response()->json([
            'status' => 200,
            'message' => 'update item success',
        ], 200);


    }
    
    public function deleteItem(Request $request)
    {
        try{
            if($request)
            $validateUser = Validator::make($request->all(), 
            [
                'type' => 'required',
                'id' => 'required',
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 500);
            }


            if($request->type == "contractor")
            {
                $res = Contractor::where('id', $request->id)->first();
                if(!isset($res))
                {
                    return response()->json([
                        'status' => false,
                        'message' => 'Not existed id',
                    ], 401);
                }

                if($request->user()->user_type != "Super" && $request->user()->workspace_id != $res->workspace_id)
                {
                    return response()->json([
                        'status' => false,
                        'message' => 'No perimission for this user',
                    ], 401);
                }
                
                $res->delete();
            }else if($request->type == "user"){
                $user2 = User::where('id', $request->id)->first();
                if($user2)
                {

                    if($request->user()->user_type != "Super" && $request->user()->workspace_id != $user2->workspace_id)
                    {
                        return response()->json([
                            'status' => false,
                            'message' => 'No perimission for this user',
                        ], 401);
                    }
                    
                    $user2->delete();
                }
            } else if($request->type == "floor") {
                $user2 = Floor::where('id', $request->id)->first();
                if($user2)
                {
                    if($request->user()->user_type != "Super" && $request->user()->workspace_id != $user2->workspace_id)
                    {
                        return response()->json([
                            'status' => false,
                            'message' => 'No perimission for this user',
                        ], 401);
                    }
                    $user2->delete();
                }
            } else if($request->type == "unit"){
                $user2 = Unit::where('id', $request->id)->first();
                if($user2)
                {
                    if($request->user()->user_type != "Super" && $request->user()->workspace_id != $user2->workspace_id)
                    {
                        return response()->json([
                            'status' => false,
                            'message' => 'No perimission for this user',
                        ], 401);
                    }
                    $user2->delete();
                }
            }
            else if($request->type == "section") {
                $project = Project::with('floors.units.sections.subsections')->where('id', $request->id)->first();

                if($request->user()->user_type != "Super" && $request->user()->workspace_id != $project->workspace_id)
                {
                    return response()->json([
                        'status' => false,
                        'message' => 'No perimission for this user',
                    ], 401);
                }

                if($project)
                {
                    foreach($project->floors as $floor1)
                    {
                        foreach($floor1->units as $unit1)
                        {
                            foreach($unit1->sections as $section1)
                            {
                                if($section1->name == $request->label)
                                {
                                    foreach($section1->subsections as $subsections1)
                                    {
                                        $user3 = SubSection::where('id', $subsections1->id)->first();
                                        if($user3)
                                        {
                                            $user3->delete();
                                        }
                                    }
                                    $user2 = Section::where('id', $section1->id)->first();
                                    if($user2)
                                    {
                                        $user2->delete();
                                    }
                                }
                                
                            }
                        }
                    }
                }
            }else if($request->type == "room") {
                $project = Project::with('floors.units.sections.subsections')->where('id', $request->id)->first();

                if($request->user()->user_type != "Super" && $request->user()->workspace_id != $project->workspace_id)
                {
                    return response()->json([
                        'status' => false,
                        'message' => 'No perimission for this user',
                    ], 401);
                }

                if($project)
                {
                    foreach($project->floors as $floor1)
                    {
                        foreach($floor1->units as $unit1)
                        {
                            foreach($unit1->sections as $section1)
                            {
                                foreach($section1->subsections as $subsections1)
                                {
                                    $user3 = SubSection::where('id', $subsections1->id)->first();
                                    if($user3)
                                    {
                                        $user3->delete();
                                    }
                                }
                                $user2 = Section::where('id', $section1->id)->first();
                                if($user2)
                                {
                                    $user2->delete();
                                }
                            }
                        }
                    }
                }
            }

           

           
            return response()->json([
                'status' => 200,
                'message' => 'update customer updated',
                'errors' => $validateUser->errors()
            ], 200);


        }catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ]);
        }
    }
}
