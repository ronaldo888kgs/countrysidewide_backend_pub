<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Web\Controller;
use Illuminate\Http\Request;
use App\Models\Workspace;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class WorkspaceController extends Controller
{
    //
    public function getAllWorkspaces(Request $request)
    {
        $workspaces =    Workspace::all();
        return response()->json([
            'status' => 200,
            'workspaces' => $workspaces
        ], 200);
    }

    public function createWorkspace(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'name' => 'required',
        ]);
        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 401);
        }

        $workspace = Workspace::create([
            'name' => $request->name
        ]);
        return response()->json([
            'status' => 200,
            'message' => 'Created a workspace',
        ], 200);
    }


    public function deleteWorkspace(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'id' => 'required',
        ]);
        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 401);
        }

        $workspace = Workspace::where('id', $request->id)->first();
        if (!isset($workspace))
        {
            return response()->json([
                'status' => false,
                'message' => 'Not found workspace you have selected',
            ], 401);
        }

        $workspace->delete();
        return response()->json([
            'status' => 200,
            'message' => 'Success to delete the workspace',
        ], 200);
    }
    public function updateWorkspace(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'name' => 'required',
            'id' => 'required',
        ]);
        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 401);
        }

        $workspace = Workspace::where('id', $request->id)->first();
        if (!isset($workspace))
        {
            return response()->json([
                'status' => false,
                'message' => 'Not found workspace you have selected',
            ], 401);
        }

        $workspace->name = $request->name;
        $workspace->save();

        return response()->json([
            'status' => 200,
            'message' => 'Success to update the workspace',
        ], 200);
    }
}
