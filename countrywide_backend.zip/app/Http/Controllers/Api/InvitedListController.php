<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Web\Controller;
use Illuminate\Http\Request;
use App\Models\InvitedList;
use App\Models\Project;
use Illuminate\Support\Facades\DB;
use App\Models\Notification;
use Illuminate\Support\Facades\Validator;


class InvitedListController extends Controller
{
    //

    public function delInviteUser(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'invidtedId' => 'required',
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        $listItem = InvitedList::where('id', $request->invidtedId)->first();
        $listItem->delete();
        return response()->json([
            'status' => 200,
            'msg' => "Success to delete invite list",
        ], 200);
    }

    public function addInviteUser(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'invitee_id' => 'required',
            'project_id' => 'required',
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        $oldOne = InvitedList::where('inviter', $request->user()->id)
                            ->where('invitee', $request->invitee_id)
                            ->where('project_id', $request->project_id)->first();
        if(isset($oldOne))
        {
            return response()->json([
                'status' => 200,
                'msg' => "already invited user",
            ], 200);
        }

        InvitedList::create([
            'project_id' => $request->project_id,
            'invitee' => $request->invitee_id,
            'inviter' => $request->user()->id,
        ]);

        $project = Project::where('id', $request->project_id)->first();
        $mentionTarget = $project->name;

        Notification::create([
            'target' => $request->invitee_id,
            'createdyBy' => $request->user()->id,
            'content' => '{"type":"invited", "project":'.$request->project_id.', "target":'.$request->invitee_id.', "by":'.$request->user()->id.', "mentionTarget": "'.$mentionTarget.'"}',
            'read' => 0
        ]);
        event(new \App\Events\InviteNotificationEvent( $project, $request->invitee_id));

        return response()->json([
            'status' => 200,
            'msg' => "success to invite",
        ], 200);

        //need to send email
    }

    public function getInviteUsers(Request $request)
    {
        $userId = $request->user()->id;

        // => function($inviter){
        //     $inviter->select('name as inviter_name', 'email as inviter_email', 'id as inviter_id');
        //  }
        $res = DB::table('invited_lists')
        ->leftJoin('users as invitees', 'invited_lists.invitee', '=', 'invitees.id')
        ->select('invited_lists.*', 'invitees.email as invitee_email')
        ->leftJoin('users as inviters', 'invited_lists.inviter', '=', 'inviters.id')
        ->select('inviters.email as inviter_email', 'invitees.email as invitee_email', 'invited_lists.*')
        ->leftJoin('projects', 'invited_lists.project_id', '=', 'projects.id')
        ->select('inviters.email as inviter_email', 
        'invitees.email as invitee_email', 
        'invited_lists.*', 
        'projects.name as project_name', 
        'invited_lists.created_at as invited_created_at')
        ->where('invited_lists.inviter', $userId)
        ->get();


        // $res = InvitedList
        // ::with(['inviter' => function($inviter){return (['inviter_id' =>$inviter->get()]);}, 'invitee', 'project'])
        // // ->select(['inviter.id as inviter_id'])
        // // ->where('inviter.inviter_id', $userId)
        // // ->select('invited_lists.id as list_id', 
        // //         'invited_lists.created_at as created_at', 
        // //         )
        //  ->get();

        return response()->json([
            'status' => 200,
            'invitedList' => $res,
        ], 200);
    }
}
