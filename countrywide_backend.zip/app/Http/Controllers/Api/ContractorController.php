<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Web\Controller;
use Illuminate\Http\Request;
use App\Models\Contractor;
use Illuminate\Support\Facades\Validator;

class ContractorController extends Controller
{
    //
    public function getAllContractors(Request $request)
    {
        $res = null;
        if($request->user()->user_type != "Super")
        {
            $res = Contractor::where('workspace_id', $request->user()->workspace_id)->get();
        } else {
            $res = Contractor::all();
        }
        
        return response()->json([
            'status' => 200,
            'contractors' => $res
        ], 200);
    }

    public function addContractor(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'name' => 'required',
        ]);
        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 401);
        }

        Contractor::create(['name' => $request->name, 'workspace_id' => $request->user()->workspace_id]);

        return response()->json([
            'status' => 200,
            'message' => 'success to add new contractor',
        ], 200);
    }


    public function deleteContractor(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'id' => 'required',
            'name' => 'required',

        ]);
        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 401);
        }
        $res = Contractor::where('id', $request->id)->where('workspace_id', $request->user()->workspace_id)->first();
        if(!isset($res))
        {
            return response()->json([
                'status' => false,
                'message' => 'Not existed id',
            ], 401);
        }
        $res->delete();
        return response()->json([
            'status' => 200,
            'message' => 'update contractor updated',
        ]);

    }

    public function updateContractor(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'id' => 'required',
            'name' => 'required',

        ]);
        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 401);
        }
        $res = Contractor::where('id', $request->id)->where('workspace_id', $request->user()->workspace_id)->first();
        if(!isset($res))
        {
            return response()->json([
                'status' => false,
                'message' => 'Not existed id',
            ], 401);
        }
        $res->name = $request->name;
        $res->save();

        return response()->json([
            'status' => 200,
            'message' => 'update contractor updated',
        ]);

    }
}
