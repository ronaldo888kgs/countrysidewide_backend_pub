<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Web\Controller;
use Illuminate\Http\Request;
use App\Models\SubSection;
use App\Models\Project;
use App\Models\History;
use App\Models\Media;
use Illuminate\Support\Facades\Validator;

class SubSectionController extends Controller
{
    //


    public function updateAttahcments(Request $request)
    {
        $allSubs = SubSection::with('mediafiles')->get();
        foreach($allSubs as $sub)
        {
            if(count($sub->mediafiles) > 0)
            {
                $obj = SubSection::where('id', $sub->id)->first();
                $obj->attachments = 1;
                $obj->save();
            }
        }
        return response()->json([
            'status' => 200,
            'subsection' => "success",
        ], 200);

    }

    public function getSubSectionById(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'subsection_id' => 'required',
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        $res = SubSection::with('comments')->with('mediafiles')->where('id', $request->subsection_id)->first();

        return response()->json([
            'status' => 200,
            'subsection' => $res,
        ], 200);
    }


    public function getStringByStatus($status)
    {
        switch($status)
        {
            case 0:
                return "No Room in this area";
                break;
            case 1:
                return "Not Ready";
                break;
            case 2:
                return "Ready to be measured";
                break;
            case 3:
                return "measured";
                break;
            case 4:
                return "Ticketed";
                break;
            case 5:
                return "Installed";
                break;
            case -1:
                return "Clear";
                break;
        }
        return 'UNKNOWN';
    }

    public function changeStatus(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'status' => 'required',
            'subsection_id' => 'required',
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        $subsection = SubSection::where('id', $request->subsection_id)->first();
        if(isset($subsection))
        {
            $subsection->status = $request->status;
            if(isset($request->notes))
            {
                $subsection->notes = $request->notes;
            }else{
                $subsection->notes = "";
            }
            $subsection->save();
        }

        // $project = Project::with('floors.units.sections.subsections')->where('subsection.id', $request->subsection_id)->first();
        $project = SubSection::with('section.unit.floor')->where('id', $request->subsection_id)->first();

        //dd($project);

        History::create([
            'item_name' => $subsection->name, 
            'project_id' => $project->section->unit->floor->project_id,
            'model_id' => $subsection->id,
            'status_history' => 'Changed status to '.$this->getStringByStatus($request->status),
            'workspace_id' => $request->user()->workspace_id,
            'user_name' => $request->user()->name]
        );

        
        return response()->json([
            'status' => 200,
            'message' => 'success to update sub section status',
        ], 200);
    }

    public function completionStatus(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'data' => 'required',
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 200);
        }

        for($j = 0 ; $j < count($request->data) ; $j++)
        {
            $item = $request->data[$j];
            $subsection = SubSection::where('id', $item['id'])->first();
            if(isset($subsection))
            {
                $subsection->completion_status = $item['status'];
                $subsection->status = $item['status'] == 1 ? -1 : 0;
                $subsection->save();
            }
        }

        return response()->json([
            'status' => 200,
            'message' => 'success to update sub section status',
        ], 200);
    }
}
