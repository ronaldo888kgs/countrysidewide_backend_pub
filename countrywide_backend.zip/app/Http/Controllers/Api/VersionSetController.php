<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Web\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\VersionSet;


class VersionSetController extends Controller
{
    //


    public function getVersionSet(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'project_id' => 'required',
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        $res = VersionSet::where('project_id', $request->project_id)->where('workspace_id', $request->user()->workspace_id)->get();

        return response()->json([   
            'status' => 200,
            'versionSet' => $res,
        ], 200);
    }

    public function addNewVersionSet(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'due_date' => 'required',
            'name' => 'required',
            'project_id' => 'required',
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        $newVersion = VersionSet::create([
            'due_date' => $request->due_date,
            'name' => $request->name,
            'project_id' => $request->project_id,
            'workspace_id' => $request->user()->workspace_id,
            'createdyBy' => $request->user()->id,
        ]);

        return response()->json([
            'status' => 200,
            'versionSetId' => $newVersion->id,
        ], 200);

        


    }
}
