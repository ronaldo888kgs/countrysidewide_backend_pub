<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Web\Controller;
use Illuminate\Http\Request;
use App\Models\Media;
use App\Models\Notification;
use App\Models\SubSection;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\DB;

class NotificationController extends Controller
{
    //

    public function readNotification(Request $request)
    {
        if($request->ids)
        {
            foreach($request->ids as $id)
            {
                $obj = Notification::where('id', $id)->first();
                if(isset($obj))
                {
                    $obj->read = 1;
                    $obj->save();
                }
            }

            return response()->json([
                'status' => 200,
                'message' => 'read notification 222',
    
            ], 200); 
        }else if($request->id)
        {
            $obj = Notification::where('id', $request->id)->first();
            if(isset($obj))
            {
                $obj->read = 1;
                $obj->save();
            }
        }
       
        return response()->json([
            'status' => 200,
            'message' => 'read notification',

        ], 200); 
    }
    public function getNotifications(Request $request)
    {
        $res = Notification::with('creater')->where('target', $request->user()->id)->orderBy('created_at', 'desc')->get();
        return response()->json([
            'status' => 200,
            'message' => 'result of getting notifications',
            'notifications' => $res,
        ], 200);
    }


    public function markasRead(Request $request)
    {
        $notifi = Notification::where('id', $request->id)->first();
        if($notifi)
        {
            $notifi->read = 1;
            $notifi->save();
        }

        return response()->json([
            'status' => 200,
            'message' => 'success to mark as unread',
        ], 200);
    }

    public function markUnreadNotification(Request $request)
    {
        $notifi = Notification::where('id', $request->id)->first();
        if($notifi)
        {
            $notifi->read = 0;
            $notifi->save();
        }

        return response()->json([
            'status' => 200,
            'message' => 'success to mark as unread',
        ], 200);
    }

    public function readAllNotifications(Request $request)
    {
        Notification::where('target', $request->user()->id)->update(['read' => 1]);
        
        return response()->json([
            'status' => 200,
            'message' => 'success to read all notifications',
        ], 200);
    }

    public function addMentions(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'mentions' => 'required',
            'project_id' => 'required',
            'subsection_id' => 'required',
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        $subsection = SubSection::with('section.unit.floor.project')->where('id', $request->subsection_id)->first();
        $mentionTarget = $subsection->section->unit->floor->project->name.' / '
                        .$subsection->section->unit->floor->name.' / '
                        .$subsection->section->unit->name.' / '
                        .$subsection->section->name.' / '
                        .$subsection->name;


        $tmplist = 'test';

        foreach($request->mentions as $mention)
        {
            $tmplist = $tmplist. $mention["targetId"].',';
            Notification::create([
                'target' => $mention["targetId"],
                'createdyBy' => $request->user()->id,
                'content' => '{ "type": "mentioned", "subsection": '.$request->subsection_id.', "project": '.$request->project_id.', "target":'.$mention["targetId"].', "by":'.$request->user()->id.', "mentionTarget": "'.$mentionTarget.'"}',
                'read' => 0
            ]);
            event(new \App\Events\InviteNotificationEvent( 'You mentioned on subsection-'.$request->subsection_id, $mention["targetId"]));
        }


        return response()->json([
            'status' => 200,
            'message' => 'success to add notification'.$tmplist,
        ], 200);
    }
}
