<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Web\Controller;
use Illuminate\Http\Request;
use App\Models\Purchasing;
use App\Models\Submittal;
use Illuminate\Support\Facades\Validator;

class PurchasingController extends Controller
{
    //

    public function getPurchasingList(Request $request) {
        $id = $request->get('project_id');

        $res = Purchasing::with(['mediafiles' => function($query){
            $query->where('type', 'Purchasing')->get();
        }])->where('project_id', $id)->get();
        return response()->json([
            'status' => 200,
            'purchasings' => $res,
        ], 200);
    }
    //
    public function addToPurchasing(Request $request){
        $validateUser = Validator::make($request->all(), 
        [
            'project_id' => 'required'
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        $desc = '';
        if(isset($request->submittal_id))
        {
            $submit = Submittal::where('id', $request->submittal_id)->first();

            $desc = $submit->desc;
            Purchasing::create([
                'tag' => isset($submit->name) ? $submit->name : "",
                'supplier' => isset($submit->supplier) ? $submit->supplier : "",
                'unit' => isset($submit->unit) ? $submit->unit : "",
                'desc' => isset($submit->desc) ? $submit->desc : "",
                'workspace_id' => $request->user()->workspace_id,
                'user_id' => $request->user()->id,
                'project_id' => $request->project_id,
                'area' => isset($request->area) ? $request->area : "",
                'order_status' => isset($request->order_status) ? $request->order_status : "",
                'net_qty' => isset($request->net_qty) ? $request->net_qty : 0,
                'waste' => isset($request->waste) ? $request->waste : 0,
                'attic_stock' => isset($request->attic_stock) ? $request->attic_stock : "",
                'gross_qty' => isset($request->gross_qty) ? $request->gross_qty : 0,
                'remaining' => isset($request->remaining) ? $request->remaining : "",
                'order_qty' => isset($request->order_qty) ? $request->order_qty : 0,
                'order_number' => isset($request->order_number) ? $request->order_number : 0,
                'payment_status' => isset($request->payment_status) ? $request->payment_status : "",
                'lead_time' => isset($request->lead_time) ? $request->lead_time : null,
                'notes' => isset($request->notes) ? $request->notes : "",
            ]);
        }else{
            Purchasing::create([
                'tag' => isset($request->tag) ? $request->tag : "",
                'supplier' => isset($request->supplier) ? $request->supplier : "",
                'unit' => isset($request->unit) ? $request->unit : "",
                'desc' => isset($request->desc) ? $request->desc : "",
                'workspace_id' => $request->user()->workspace_id,
                'user_id' => $request->user()->id,
                'project_id' => $request->project_id,
                'area' => isset($request->area) ? $request->area : "",
                'order_status' => isset($request->order_status) ? $request->order_status : "",
                'net_qty' => isset($request->net_qty) ? $request->net_qty : 0,
                'waste' => isset($request->waste) ? $request->waste : 0,
                'attic_stock' => isset($request->attic_stock) ? $request->attic_stock : "",
                'gross_qty' => isset($request->gross_qty) ? $request->gross_qty : 0,
                'remaining' => isset($request->remaining) ? $request->remaining : "",
                'order_qty' => isset($request->order_qty) ? $request->order_qty : 0,
                'order_number' => isset($request->order_number) ? $request->order_number : 0,
                'payment_status' => isset($request->payment_status) ? $request->payment_status : "",
                'lead_time' => isset($request->lead_time) ? $request->lead_time : null,
                'notes' => isset($request->notes) ? $request->notes : "",
            ]);
        }

        
        
        return response()->json([
            'status' => 200,
            'message' => 'Success to create Purchasing Item',
            'desc' => $desc
        ], 200);
    }

    public function updatePurchasingItem(Request $request)
    {
        $oldOne = Purchasing::where('id', $request->purchasing_id)->first();
        if(!isset($oldOne))
        {
            return response()->json([
                'status' => 500,
                'message' => 'Not found Purchasing Item',
            ], 200);
        }

        $oldOne->order_status = isset($request->order_status) ? $request->order_status : '';
        $oldOne->area = isset($request->area) ? $request->area : '';
        $oldOne->net_qty = isset($request->net_qty) ? $request->net_qty : 0;
        $oldOne->waste = isset($request->waste) ? $request->waste : 0;
        $oldOne->attic_stock = isset($request->attic_stock) ? $request->attic_stock : '';
        $oldOne->gross_qty = isset($request->gross_qty) ? $request->gross_qty : 0;
        $oldOne->remaining = isset($request->remaining) ? $request->remaining : '';
        $oldOne->order_qty = isset($request->order_qty) ? $request->order_qty : 0;
        $oldOne->order_number = isset($request->order_number) ? $request->order_number : 0;
        $oldOne->payment_status = isset($request->payment_status) ? $request->payment_status : '';
        $oldOne->lead_time = isset($request->lead_time) ? $request->lead_time : '';
        $oldOne->notes = isset($request->notes) ? $request->notes : '';
        $oldOne->tag = isset($request->tag) ? $request->tag : '';
        $oldOne->supplier = isset($request->supplier) ? $request->supplier : null;
        $oldOne->unit = isset($request->unit) ? $request->unit : '';
        $oldOne->desc = isset($request->desc) ? $request->desc : '';
        $oldOne->save();

        return response()->json([
            'status' => 200,
            'message' => 'Success to update Purchasing Item',
        ], 200);
    }
    
    public function deletePurchasingItem(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'purchasing_id' => 'required',
        ]);


        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }
        
        $oldOne = Purchasing::where('id', $request->purchasing_id)->first();
        if(!isset($oldOne))
        {
            return response()->json([
                'status' => 500,
                'message' => 'Not found Purchasing Item',
            ], 200);
        }

        $oldOne->delete();

        return response()->json([
            'status' => 200,
            'message' => 'Success to delete Inventory Item',
        ], 200);
    }
}
