<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Web\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\ShowDrawing;
use Illuminate\Support\Facades\URL;

class ShowDrawingController extends Controller
{
    //

    public function changeOrderShopDrowings(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'orders' => 'required',
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        foreach($request->orders as $order )
        {
            $res = ShowDrawing::where('id', $order["id"])->first();
            $res->order = $order["order"];
            $res->save();
        }
        
        return response()->json([
            'status' => 200,
            'msg' => 'success to change',
            // 'tmpdata = ' => $tmpData
        ], 200);
    }
    public function deleteDrawing(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'id' => 'required',
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        $draw = ShowDrawing::where('id', $request->id)->first();
        if(isset($draw))
        {
            $draw->delete();

        }

        return response()->json([
            'status' => 200,
            'msg' => 'success to delete',
            // 'tmpdata = ' => $tmpData
        ], 200);

    }

    public function updateDrawing(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'project_id' => 'required',
            'drawing_id' => 'required',
            'type' => 'required',
            'name' => 'required',
            'description' => 'required',
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 200);
        }

        $oldData = ShowDrawing::where('id', $request->drawing_id)->first();
        if(!isset($oldData))
        {
            return response()->json([
                'status' => false,
                'message' => 'Not found selected drawing',
            ], 200);
        }

        $oldData->name = $request->name;
        $oldData->description = $request->description;

        if(isset($oldData->file) && count($oldData->file))
        {
            foreach($request->file as $i => $file)
            {
                $extension = strtolower($file->extension());
                $filename = time().'_'.$i.'_.'.$extension;
                $path = public_path('../../public_html/backend/public/drawings/');    
                // $path = public_path('public/drawings/');    
                $file->move($path, $filename);
                $oldData->url = URL::asset('public/drawings/'.$filename);
            }
        }

        $oldData->save();

        return response()->json([
            'status' => 200,
            'message' => 'Success to update drawing',
        ], 200);
    }

    public function addDrawing(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'project_id' => 'required',
            'type' => 'required',
            'name' => 'required',
            'description' => 'required',
            'file' => 'required',
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        $tmpData = '';
        foreach($request->file as $i => $file)
        {
            $extension = strtolower($file->extension());
            $filename = time().'_'.$i.'_.'.$extension;
            $path = public_path('../../public_html/backend/public/drawings/');    
            // $path = public_path('public/drawings/');    
            $file->move($path, $filename);

            //     'url' => $filename
            // $tmpData .= '   == , '.$filename;
            ShowDrawing::Create([
                'name' => $request->name,
                'description' => $request->description,
                'type' => $request->type,
                'project_id' => $request->project_id,
                'workspace_id' => $request->user()->workspace_id,
                'created_by' => $request->user()->id,
                'url' =>  URL::asset('public/drawings/'.$filename)
            ]); 
        }


        $res = ShowDrawing::where('project_id', $request->project_id)->get();

        return response()->json([
            'status' => 200,
            'drawinglist' => $res,
            // 'tmpdata = ' => $tmpData
        ], 200);



        
    }

    public function getDrawingList(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'project_id' => 'required'
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        $res = ShowDrawing::where('project_id', $request->project_id)->orderBy('order', 'asc')->get();

        return response()->json([
            'status' => 200,
            'drawinglist' => $res,
        ], 200);
    }
}
