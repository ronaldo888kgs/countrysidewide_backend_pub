<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Web\Controller;
use Illuminate\Http\Request;
use App\Models\Media;
use App\Models\SubSection;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\DB;

class MediaFilesController extends Controller
{


    public function deleteMedia(Request $request)
    {
        
        $validateUser = Validator::make($request->all(), 
        [
            'media_id' => 'required',

        ]);
        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }
        $res = Media::where('id', $request->media_id)->first();
        if(!isset($res))
        {
            return response()->json([
                'status' => false,
                'message' => 'Not existed id',
            ], 500);
        }

        if($res->type === "Project")
        {
            $obj = SubSection::where('id', $res->model_id)->first();
            if(isset($obj))
            {
                $obj->attachments = 0;
                $obj->save();
            }
        }

        $res->delete();
        return response()->json([
            'status' => 200,
            'message' => 'update contractor updated',
        ]);

    }

    public function mediaList (Request $request)
    {
        // $media = Media::with('subsection.section.unit.floor.project')->get();
        // ＄users = DB::table('users')
        //     ->leftJoin('posts', 'users.id', '=', 'posts.user_id')
        //     ->get();// joining the posts table , where user_id and posts_user_id are same
        // $media = DB::table('medias')
        //             ->leftJoin('sub_sections', 'medias.model_id', '=', 'sub_sections.id')
        //             ->leftJoin('sections', 'sub_sections.section_id', '=', 'sections.id')
        //             ->leftJoin('units', 'sections.unit_id', '=', 'units.id')
        //             ->leftJoin('floors', 'units.floor_id', '=', 'floors.id', 'floors.id', '=', $request->get('project_id'))
        //             ->where('medias.type', '=', 'Project')->get();

        if( $request->get('subsection_id') !== null)
        {
            $subsection_id = $request->get('subsection_id');

            $media = DB::table('medias')
            ->leftJoin('sub_sections', 'medias.model_id', '=', 'sub_sections.id')
            ->leftJoin('sections', 'sub_sections.section_id', '=', 'sections.id')
            ->leftJoin('units', 'sections.unit_id', '=', 'units.id')
            ->leftJoin('floors', function($join){
                $join->on('units.floor_id', '=', 'floors.id');
                // $join->on('floors.project_id', '=', $request->get('project_id'));
            })->where('sub_sections.id', $subsection_id)
            ->where('medias.workspace_id' , $request->user()->workspace_id,)
            ->select('medias.id as media_id', 'medias.workspace_id as workspace_id', 'medias.created_at as media_created_at', 'medias.*', 'sub_sections.*', 'sections.*', 'units.*', 'floors.*')->get();
            return response()->json([
                'status' => 200,
                'history' => $media,
            ], 200);
        }

        $media = DB::table('medias')
            ->leftJoin('sub_sections', 'medias.model_id', '=', 'sub_sections.id')
            ->leftJoin('sections', 'sub_sections.section_id', '=', 'sections.id')
            ->leftJoin('units', 'sections.unit_id', '=', 'units.id')
            ->leftJoin('floors', function($join){
                $join->on('units.floor_id', '=', 'floors.id');
                // $join->on('floors.project_id', '=', $request->get('project_id'));
            })->where('project_id', $request->get('project_id'))
            ->where('medias.workspace_id' , $request->user()->workspace_id,)
            ->select('medias.id as media_id', 'medias.workspace_id as workspace_id',  'medias.created_at as media_created_at', 'medias.*', 'sub_sections.*', 'sections.*', 'units.*', 'floors.*')->get();


        $media2 = DB::table('medias')
            ->leftJoin('tasks', 'medias.model_id', '=', 'tasks.id')
            ->where('project_id', $request->get('project_id'))
            ->select('medias.id as media_id',  'medias.created_at as media_created_at',  'medias.*', 'tasks.*')
            ->where('medias.workspace_id' , $request->user()->workspace_id,)->get();


        // $res = [];
        // foreach($media as $item)
        // {
        //     if($item->subsection->section->unit->floor->project_id == $request->get('project_id'))
        //     {
        //         array_push($res, $item);
        //     }
        // }
        return response()->json([
            'status' => 200,
            'history' => $media,
            'history2' => $media2,
        ], 200);
    }

    public function getPdfFile($filename)
    {
        $file=Storage::disk('public')->get($filename);
  
        return (new Response($file, 200))
              ->header('Content-Type', 'pdf');
    }

    function compress($source, $destination, $quality) {

        $info = getimagesize($source);
    
        if ($info['mime'] == 'image/jpeg') 
            $image = imagecreatefromjpeg($source);
    
        elseif ($info['mime'] == 'image/gif') 
            $image = imagecreatefromgif($source);
    
        elseif ($info['mime'] == 'image/png') 
            $image = imagecreatefrompng($source);
    
                     
        $image = imagerotate($image, -90, 0);
        
        return imagejpeg($image, $destination, $quality);
    
        // return $destination;
    }

    //
    public function fileStore(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'model_id' => 'required',
            'type' => 'required',
            'file' => 'required'
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }


        if($request->type === "Project")
        {
            $obj = SubSection::where('id', $request->model_id)->first();
            $obj->attachments = 1;
            $obj->save();
        }


        foreach($request->file as $file)
        {
            $extension = strtolower($file->extension());
            $filename = time().'_.'.$extension;

            $path = public_path('../../public_html/backend/public/img/');
            if(str_contains($extension, "pdf"))
            {
                $path = public_path('../../public_html/backend/public/doc/');    
            }


            

            
            if(str_contains($extension, "pdf"))
            {
                
                $file->move($path, $filename);
                Media::create([
                    'model_id' => $request->model_id, 
                    'type' => $request->type, 
                    'user_id' => $request->user()->id,
                    'description' => $request->description ? $request->description : '',
                    'file' => $filename,
                    'workspace_id' => $request->user()->workspace_id,
                    'url' => URL::asset('public/doc/'.$filename),
            ]);
            } else { // for image
                $file->move($path, $filename);
                // $this->compress($path.$filename, $path.'compressed/'.$filename, 50);
                $this->compress($path.$filename, $path.$filename, 50);

                Media::create([
                    'model_id' => $request->model_id, 
                    'type' => $request->type, 
                    'user_id' => $request->user()->id,
                    'description' => $request->description ? $request->description : '',
                    'file' => $filename,
                    'workspace_id' => $request->user()->workspace_id,
                    'url' => URL::asset('public/img/'.$filename),
                ]);
            }
            
        }

        

        

        return response()->json([
            'status' => 200,
        ], 200);


        // $media = Media([
        //     'model_id' => $request->model_id, 
        //     'type' => $request->type,
        // ]);

    }
}
