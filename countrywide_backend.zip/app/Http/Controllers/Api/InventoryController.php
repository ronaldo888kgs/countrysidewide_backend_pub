<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Web\Controller;
use Illuminate\Http\Request;
use App\Models\Inventory;
use App\Models\Submittal;
use Illuminate\Support\Facades\Validator;

class InventoryController extends Controller
{

    public function getInventoryList(Request $request) {
        $id = $request->get('project_id');

        $res = Inventory::with(['mediafiles' => function($query){
            $query->where('type', 'Inventory')->get();
        }])->where('project_id', $id)->get();

        return response()->json([
            'status' => 200,
            'inventory' => $res,
        ], 200);
    }
    //
    public function addToInventory(Request $request){
        $validateUser = Validator::make($request->all(), 
        [
            'project_id' => 'required'
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        if(isset($request->submittal_id))
        {
            $submit = Submittal::where('id', $request->submittal_id)->first();

            Inventory::create([
                'workspace_id' => $request->user()->workspace_id,
                'user_id' => $request->user()->id,
                'project_id' => $request->project_id,
                'order_status' => isset($request->order_status) ? $request->order_status : '',   
                'status' => isset($request->status) ? $request->status : '',
                'ordered_qty' => isset($request->ordered_qty) ? $request->ordered_qty : '',
                'received_qty' => isset($request->received_qty) ? $request->received_qty : '',
                'location' => isset($request->location) ? $request->location : '',
                'notes' => isset($request->notes) ? $request->notes : '',
                'tag' => isset($submit->name) ? $submit->name : '',
                'supplier' => isset($submit->supplier) ? $submit->supplier : '',
                'unit' => isset($submit->unit) ? $submit->unit : '',
                'desc' => isset($submit->desc) ? $submit->desc : '',
            ]);
        }else{
            Inventory::create([
                'workspace_id' => $request->user()->workspace_id,
                'user_id' => $request->user()->id,
                'project_id' => $request->project_id,
                'order_status' => isset($request->order_status) ? $request->order_status : '',   
                'status' => isset($request->status) ? $request->status : '',
                'ordered_qty' => isset($request->ordered_qty) ? $request->ordered_qty : '',
                'received_qty' => isset($request->received_qty) ? $request->received_qty : '',
                'location' => isset($request->location) ? $request->location : '',
                'notes' => isset($request->notes) ? $request->notes : '',
                'tag' => isset($request->tag) ? $request->tag : '',
                'supplier' => isset($request->supplier) ? $request->supplier : '',
                'unit' => isset($request->unit) ? $request->unit : '',
                'desc' => isset($request->desc) ? $request->desc : '',
            ]);
        }

        

        return response()->json([
            'status' => 200,
            'message' => 'Success to create Inventory Item',
        ], 200);
    }

    public function updateInventoryItem(Request $request)
    {
        $oldOne = Inventory::where('id', $request->inventory_id)->first();
        if(!isset($oldOne))
        {
            return response()->json([
                'status' => 500,
                'message' => 'Not found Inventory Item',
            ], 200);
        }

        $oldOne->order_status = isset($request->order_status) ? $request->order_status : '';
        $oldOne->status = isset($request->status) ? $request->status : '';
        $oldOne->ordered_qty = isset($request->ordered_qty) ? $request->ordered_qty : '';
        $oldOne->received_qty = isset($request->received_qty) ? $request->received_qty : '';
        $oldOne->location = isset($request->location) ? $request->location : '';
        $oldOne->notes = isset($request->notes) ? $request->notes : '';
        $oldOne->tag = isset($request->tag) ? $request->tag : '';
        $oldOne->supplier = isset($request->supplier) ? $request->supplier : '';
        $oldOne->unit = isset($request->unit) ? $request->unit : '';
        $oldOne->desc = isset($request->desc) ? $request->desc : '';
        $oldOne->save();

        return response()->json([
            'status' => 200,
            'message' => 'Success to update Inventory Item',
        ], 200);
    }
    
    public function deleteInventoryItem(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'inventory_id' => 'required',
        ]);


        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }
        
        $oldOne = Inventory::where('id', $request->inventory_id)->first();
        if(!isset($oldOne))
        {
            return response()->json([
                'status' => 500,
                'message' => 'Not found Inventory Item',
            ], 200);
        }

        $oldOne->delete();

        return response()->json([
            'status' => 200,
            'message' => 'Success to delete Inventory Item',
        ], 200);
    }
}
