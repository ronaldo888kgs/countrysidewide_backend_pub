<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Web\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\TicketTemplate;
use Illuminate\Support\Facades\URL;

class TicketTemplateController extends Controller
{
    //

    public function uploadTemplate(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'description' => 'required',
            'name' => 'required',
            'file' => 'required',
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }


        $extension = strtolower($request->file[0]->extension());
        $filename = time().'_.'.$extension;
        $path = public_path('../../public_html/backend/public/ticket_templates/');    
        // $path = public_path('public/ticket_templates/');    
        $request->file[0]->move($path, $filename);

        TicketTemplate::create([
            'name' => $request->name,
            'desc' => $request->description,
            'url' => URL::asset('public/ticket_templates/'.$filename),
            'workspace_id' => $request->user()->workspace_id,
            'created_by' => $request->user()->id,
        ]);
        return  response()->json([   
            'status' => 200,
            'msg' => "Success to upload template file",
        ], 200);

    }

    public function updateTemplate(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'template_id' => 'required',
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        $id = $request->template_id;

        $res = TicketTemplate::where('id', $id)->first();

        if(!isset($res))
        {
            return  response()->json([   
                'status' => 200,
                'msg' => "Not found selected ticket template",
            ], 200);
        }

        if(isset($request->name))
        {
            $res->name = $request->name;
        }

        if(isset($request->description))
        {
            $res->desc = $request->description;
        }

        if(isset($request->file) && count($request->filr))
        {
            $extension = strtolower($request->file[0]->extension());
            $filename = time().'_.'.$extension;
            $path = public_path('../../public_html/backend/public/ticket_templates/');    
            // $path = public_path('public/ticket_templates/');    
            $request->file[0]->move($path, $filename);
            $res->url = URL::asset('public/ticket_templates/'.$filename);
        }

        $res->save();

        return  response()->json([   
            'status' => 200,
            'msg' => "Success to update template file",
        ], 200);
    }

    public function deleteTemplate(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'template_id' => 'required',
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        $id = $request->template_id;

        $res = TicketTemplate::where('id', $id)->first();

        if(!isset($res))
        {
            return  response()->json([   
                'status' => 200,
                'msg' => "Not found selected ticket template",
            ], 200);
        }

        $res->delete();

        return  response()->json([   
            'status' => 200,
            'msg' => "Success to delete template file",
        ], 200);
    }

    public function getTemplate(Request $request)
    {
        $res = TicketTemplate::where('workspace_id', $request->user()->workspace_id)->get();
        return  response()->json([   
            'status' => 200,
            'tickettemplates' => $res,
        ], 200);
    }
}
