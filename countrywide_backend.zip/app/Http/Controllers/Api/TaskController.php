<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Web\Controller;
use Illuminate\Http\Request;
use App\Models\Task;
use App\Models\Media;
use App\Models\TaskAssigment;

use Illuminate\Support\Facades\Validator;
class TaskController extends Controller
{
    //


    public function editTask(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'description' => 'required',
            'due_date' => 'required',
            'priority' => 'required',
            'project_id' => 'required',
            'status' => 'required',
            'task_id' => 'required',
            'number' => 'required',
            'assignments' => 'required'
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        $task = Task::where('id', $request->task_id)->first();
        if(!isset($task))
        {
            return response()->json([
                'status' => false,
                'message' => 'Not existed id',
            ], 500);
        }
        $task->description = $request['description'];
        $task->due_date = $request['due_date'];
        $task->priority = $request['priority'];
        $task->project_id = $request['project_id'];
        $task->status = $request['status'];
        $task->number = $request['number'];
        $task->user = $request->user()->name;
        $task->save();

        $oldAssignments = TaskAssigment::where('task_id', $request->task_id)->get();
        foreach($oldAssignments as $oldAssignment)
        {
            $oldAssignment->delete();
        }

        foreach($request->assignments as $assignment)
        {
            TaskAssigment::create([
                'task_id' => $request->task_id,
                'user_id' => $assignment
            ]);
        }



        return response()->json([
            'status' => 200,
            'message' => 'update contractor updated',
        ]);

    }
    public function deleteTask(Request $request)
    {
        
        $validateUser = Validator::make($request->all(), 
        [
            'task_id' => 'required',

        ]);
        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }
        $res = Task::where('id', $request->task_id)->first();
        if(!isset($res))
        {
            return response()->json([
                'status' => false,
                'message' => 'Not existed id',
            ], 500);
        }
        $res->delete();
        return response()->json([
            'status' => 200,
            'message' => 'update contractor updated',
        ]);

    }

    public function getAllTasks(Request $request)
    {
        $query = Task::with('mediafiles')
                    ->with(['assignment' => function($assignment){
                        return $assignment->with('user');
                    }])->where('project_id', $request->get('project_id'));
        if($request->user()->user_type != "Super")
            $query = Task::with('mediafiles')
            ->with(['assignment' => function($assignment){
                return $assignment->with('user');
            }])->where('project_id', $request->get('project_id'))
            ->where('workspace_id', $request->user()->workspace_id);
        $res = null;
        if($request->get('priority'))
        {
            $res = $query->where('priority', $request->get('priority'))->get();
        } else if($request->get('status'))
        {
            $res = $query->where('status', $request->get('status'))->get();
        }else if($request->get('due_date'))
        {
            $res = $query->where('due_date', $request->get('due_date'))->get();
        }else if($request->get('due_date'))
        {
            $res = $query->where('due_date', $request->get('due_date'))->get();
        }else{
            $res = $query->get();
        }


        return response()->json([
            'status' => 200,
            'message' => 'success to get Tasks',
            'projectid' => $request->get('project_id'), 
            'tasks' => $res
        ], 200);
        // return response()->json([
        //     'status' => 200,
        //     'message' => 'success to get history',
        // ], 200);
    }

    public function addTask(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'description' => 'required',
            'due_date' => 'required',
            'priority' => 'required',
            'project_id' => 'required',
            'status' => 'required',
            'task_number' => 'required',
            'assignments' => 'required'
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        $res = Task::create([
            'number' => $request['task_number'],
            'description' => $request['description'],
            'due_date' => $request['due_date'],
            'priority' => $request['priority'],
            'project_id' => $request['project_id'],
            'status' => $request['status'],
            'attachment' => '',
            'workspace_id' => $request->user()->workspace_id,
            'user' => $request->user()->name
        ]);


        foreach($request->assignments as $assignment)
        {
            TaskAssigment::create([
                'task_id' => $res->id,
                'user_id' => $assignment
            ]);
        }


        return response()->json([
            'status' => 200,
            'message' => 'success to get Tasks',
        ], 200);
        // return response()->json([
        //     'status' => 200,
        //     'message' => 'success to get history',
        // ], 200);
    }
}
