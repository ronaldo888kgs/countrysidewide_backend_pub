<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Web\Controller;
use Illuminate\Http\Request;


use App\Models\User;
// use App\Models\Role;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class AuthController extends Controller
{

    public function resetPwd(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'email' => 'required',
            'newPwd' => 'required'
        ]);
        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 401);
        }

        $user = User::where('email', $request->email)->first();
        if(!isset($user))
        {
            return response()->json([
                'status' => false,
                'message' => 'No existed user, please create an account.',
            ], 401);
        }
        $user->password = Hash::make($request->newPwd);
        $user->save();
        return response()->json([
            'status' => 200,
            'message' => 'Success to reset password.',
        ], 200);
    }

    public function forgotUser(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'email' => 'required',
        ]);
        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 401);
        }
        $user = User::where('email', $request->email)->first();
        if(!isset($user))
        {
            return response()->json([
                'status' => false,
                'message' => 'No existed user, please create an account.',
            ], 401);
        }

        return response()->json([
            'status' => 200,
            'message' => 'Email has been checked, please reset the password',
        ], 200);
    }
     /**
     * Create User
     * @param Request $request
     * @return User 
     */
    public function createUser(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(), 
            [
                'name' => 'required',
                'email' => 'required|email|unique:users,email',
                'password' => 'required',
                'usertype' => 'required'
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }


            if($request->user()->user_type == "Super")
            {
                $user = User::create([
                    'name' => $request->name,
                    'email' => $request->email,
                    'password' => Hash::make($request->password),
                    'user_type' => $request->usertype,
                    'workspace_id' => $request->workspace_id
                ]);
            } else {
                $user = User::create([
                    'name' => $request->name,
                    'email' => $request->email,
                    'password' => Hash::make($request->password),
                    'user_type' => $request->usertype,
                    'workspace_id' => $request->user()->workspace_id
                ]);
            }

            

            return response()->json([
                'status' => true,
                'message' => 'User Created Successfully',
                'token' => $user->createToken("API TOKEN")->plainTextToken,
                'workspace' => $request->sapi_windows_cp_get
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }

    /**
     * Login The User
     * @param Request $request
     * @return User
     */
    public function loginUser(Request $request)
    {
        try {
            $validateUser = Validator::make($request->all(), 
            [
                'email' => 'required|email',
                'password' => 'required'
            ]);
        
            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }



            if(!Auth::attempt($request->only(['email', 'password']))){
                return response()->json([
                    'status' => false,
                    'message' => 'Email & Password does not match with our record.',
                ], 401);
            }

            // $user = User::where('email', $request->email)->first();


            // $user2 = User::where('email', $request->email)-> with(['role'])->first();
            $user2 = User::where('email', $request->email)->first();
            // dd($user2);

            return response()->json([
                'status' => 200,
                'message' => 'User Logged In Successfully',
                'access_token' => $user2->createToken("API TOKEN")->plainTextToken,
                'user' => $user2
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }
}
