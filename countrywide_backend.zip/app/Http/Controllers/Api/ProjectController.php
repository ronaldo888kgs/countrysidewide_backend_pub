<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Web\Controller;
use Illuminate\Http\Request;
use App\Models\Project;
use App\Models\Floor;
use App\Models\InvitedList;
use Illuminate\Support\Facades\Validator;

class ProjectController extends Controller
{

    public function getProjectById_origin(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'id' => 'required',
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        $id = $request->get('id');
        
        $res = null;

        $res = Project::where('id', $id)->get();
        return response()->json([
            'status' => 200,
            'projects' => $res
        ], 200);
    }

    public function getProjectById_floors(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'id' => 'required',
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        $id = $request->get('id');
        
        $res = null;

        $res = Project::with([
            'floors' => function($floor){
                return $floor->orderBy('item_order', 'asc')->get();
            }])
            ->where('workspace_id' , $request->user()->workspace_id)
            ->where('id', $id)
            ->get();
        
        return response()->json([
            'status' => 200,
            'projects' => $res
        ], 200);
    }

    public function getProjectById_units(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'id' => 'required',
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        $id = $request->get('id');
        
        $res = null;

        $res = Project::with([
            'floors' => function($floor){
                return $floor->with(['units' => function($units){
                    return $units->get();
                }])
                ->orderBy('item_order', 'asc')->get();
            }])
            ->where('workspace_id' , $request->user()->workspace_id)
            ->where('id', $id)
            ->get();

        return response()->json([
            'status' => 200,
            'projects' => $res
        ], 200);
    }


    public function getProjectById(Request $request) // full project
    {
        $id = $request->get('id');
        
        $res = null;

        if($request->user()->user_type == "Super" || $request->user()->user_type == "Admin")
        {
            if($request->user()->user_type != "Super")
            $res = Project::with([
                'floors' => function($floors){
                    return $floors->with(['units' => function($units){
                        $units
                        ->with(['sections' => function($section){ 
                            $res = $section->with([
                                'subsections' => function($subsections){
                                    //mediafiles
                                    //comments
                                    $subsections->select('id', 'completion_status', 'name', 'status', 'notes', 'section_id', 'attachments')->get();
                                }])
                            ->select('id', 'name', 'order_in_project', 'unit_id')
                            ->orderBy('order_in_project', 'asc')->get();
                            return $res;
                        }])
                        ->select('id', 'name', 'floor_id')
                        ->get();
                    }])
                    ->select('id', 'item_order', 'name', 'project_id')
                    ->orderBy('item_order', 'asc')
                    ->get();
                }])
                ->where('workspace_id' , $request->user()->workspace_id)
                ->where('id', $id)
                ->get();
            else
            $res = Project::with([
                'floors' => function($floors){
                    return $floors->with(['units' => function($units){
                        $units
                        ->with(['sections' => function($section){ 
                            $res = $section->with([
                                'subsections' => function($subsections){
                                    //mediafiles
                                    //comments
                                    $subsections->select('id', 'completion_status', 'name', 'status', 'notes', 'section_id', 'attachments')->get();
                                }])
                            ->select('id', 'name', 'order_in_project', 'unit_id')
                            ->orderBy('order_in_project', 'asc')->get();
                            return $res;
                        }])
                        ->select('id', 'name', 'floor_id')
                        ->get();
                    }])
                    ->select('id', 'item_order', 'name', 'project_id')
                    ->orderBy('item_order', 'asc')
                    ->get();
                }])
                ->where('id', $id)
                ->get();
        } else {

            $res = Project::with([
                'floors' => function($floors){
                    return $floors->with(['units' => function($units){
                        $units
                        ->with(['sections' => function($section){ 
                            $res = $section->with([
                                'subsections' => function($subsections){
                                    //mediafiles
                                    //comments
                                    $subsections->select('id', 'completion_status', 'name', 'status', 'notes', 'section_id', 'attachments')->get();
                                }])
                            ->select('id', 'name', 'order_in_project', 'unit_id')
                            ->orderBy('order_in_project', 'asc')->get();
                            return $res;
                        }])
                        ->select('id', 'name', 'floor_id')
                        ->get();
                    }])
                    ->select('id', 'item_order', 'name', 'project_id')
                    ->orderBy('item_order', 'asc')
                    ->get();
                }])
                ->where('workspace_id' , $request->user()->workspace_id)
                ->where('id', $id)
                ->get();
        }

        
        return response()->json([
            'status' => 200,
            'projects' => $res
        ], 200);
    }

    public function getAllProjects(Request $request)
    {
        $res = null;
        
        if($request->user()->user_type == "Super" || $request->user()->user_type == "Admin")
        {
            if($request->user()->user_type != "Super")
                // $res = Project::with(['floors' => function($floor){$floor->with('units.sections.subsections.mediafiles')->with('units.sections.subsections.comments')->orderBy('item_order', 'asc');}])
                // ->where('workspace_id' , $request->user()->workspace_id,)->get();
                $res = Project::with([
                    'floors' => function($floor){
                        return $floor->with(['units' => function($units){
                            return $units->with(['sections' => function($section){$section->with('subsections.mediafiles')->orderBy('order_in_project', 'asc');}])->get();
                        }])
                        ->with('units.sections.subsections.comments')->orderBy('item_order', 'asc')->get();
                    }])
                    ->where('workspace_id' , $request->user()->workspace_id)
                    ->get();
            else
                $res = Project::with([
                    'floors' => function($floor){
                        $floor->with(['units' => function($units){
                            return $units->with(['sections' => function($section){$section->with('subsections.mediafiles')->orderBy('order_in_project', 'asc');}])->get();
                        }])
                        ->with('units.sections.subsections.comments')->orderBy('item_order', 'asc');
                    }])
                    ->get();
        } else {
            $res = Project::with([
                'floors' => function($floor){
                    return $floor->with(['units' => function($units){
                        return $units->with(['sections' => function($section){$section->with('subsections.mediafiles')->orderBy('order_in_project', 'asc');}])->get();
                    }])
                    ->with('units.sections.subsections.comments')->orderBy('item_order', 'asc')->get();
                }])
                ->where('workspace_id' , $request->user()->workspace_id)
                ->get();
        }

        // if(!isset($res) || count($res) == 0)
        // {
        //     $res = Project::with(['floors' => function($floor){$floor->with('units.sections.subsections.mediafiles')->with('units.sections.subsections.comments')->orderBy('item_order', 'asc');}])
        //     ->where('id' , $request->user()->workspace_id,)->get(); 
        // }

        // $res = Project::with(['floors' => function($floor){$floor->with('units.sections.subsections.mediafiles')->orderBy('item_order', 'asc');}])
        //             ->get();
        
        return response()->json([
            'status' => 200,
            'projects' => $res
        ], 200);
    } 

    public function addProject(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'name' => 'required',
            'contractor' => 'required',
            'address' => 'required',
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        Project::create(['name' => $request->name, 
                        'contractor' => $request->contractor, 
                        'address' => $request->address,
                        'owner' => $request->owner ? $request->owner : ' ',
                        'workspace_id'=> $request->user()->workspace_id,
                        'user_id' => $request->user()->id]);
        return response()->json([
            'status' => 200,
            'message' => 'success to add new contractor',
        ], 200);
    }

    public function getDashboard(Request $request)
    {
        $res = null;
        if($request->user()->user_type == "Super" || $request->user()->user_type == "Admin")
        {
            if($request->user()->user_type == "Super")
                $res = Project::with('floors.units.sections.subsections', 'workspace')->get();
            else
                $res = Project::with('floors.units.sections.subsections', 'workspace')->where('workspace_id', $request->user()->workspace_id,)->get();

        } else {
            $res = Project::with('floors.units.sections.subsections', 'workspace')->where('user_id', $request->user()->id,)->where('workspace_id', $request->user()->workspace_id,)->get();
        }

        // get project list for invited
        $res2 = InvitedList::with(['project' => function($project){
            return $project->with('floors.units.sections.subsections', 'workspace' );
        }, 'inviter'])->where('invitee', $request->user()->id)->get();


        
        $stack2 = array();
        $stack = array();
        $cntCompleted = 0;
        foreach($res as $project)
        {
            $totalblock = 0;
            $greenblock = 0;

            foreach($project->floors as $floor)
            {
                foreach($floor->units as $unit)
                {
                    foreach($unit->sections as $section)
                    {
                        foreach($section->subsections as $subsection)
                        {
                            if($subsection->status != 0)
                            {
                                $totalblock++;
                                if($subsection->status == 5)
                                {
                                    $greenblock++;
                                }
                            }
                        }
                    }
                }
            }
            $percent = $totalblock == 0 ? '0%' : ceil($greenblock / $totalblock * 100).'%';
            if($percent == '100%')
            {
                $cntCompleted++;
            }
            $project['percnet'] = $percent;
            unset($project['floors']);
            array_push($stack, $project);
        }

        foreach($res2 as $invitedObj)
        {
            $totalblock = 0;
            $greenblock = 0;

            $isExisted = false;
            foreach($res as $project)
            {
                if($project->id == $invitedObj->project->id)
                {
                    $isExisted = true;
                    break;
                }
            }

            if($isExisted)
                continue;

            foreach($invitedObj->project->floors as $floor)
            {
                foreach($floor->units as $unit)
                {
                    foreach($unit->sections as $section)
                    {
                        foreach($section->subsections as $subsection)
                        {
                            if($subsection->status != 0)
                            {
                                $totalblock++;
                                if($subsection->status == 5)
                                {
                                    $greenblock++;
                                }
                            }
                        }
                    }
                }
            }
            unset($invitedObj->project['floors']);
            $percent = $totalblock == 0 ? '0%' : ceil($greenblock / $totalblock * 100).'%';
            if($percent == '100%')
            {
                $cntCompleted++;
            }
            $invitedObj->project['percnet'] = $percent;

            array_push($stack2, $invitedObj);
        }


        return response()->json([
            'status' => 200,
            'projects' => $stack,
            'total' => count($res),
            'completed' => $cntCompleted,
            'pending' => (count($res) - $cntCompleted),
            'invited' => $stack2
        ], 200);
    }


    public function deleteProject(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'project_id' => 'required',

        ]);
        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }
        $res = Project::where('id', $request->project_id)->first();
        if(!isset($res))
        {
            return response()->json([
                'status' => false,
                'message' => 'Not existed id',
            ], 500);
        }
        $res->delete();
        return response()->json([
            'status' => 200,
            'message' => 'update contractor updated',
        ]);

    }


    public function getProjectInWorkspace(Request $request)
    {
        $res = Project::where('workspace_id', $request->user()->workspace_id)->get();
        return response()->json([
            'status' => 200,
            'projects' => $res,
        ]);

    }

    public function updateProject(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'id' => 'required',
            'name' => 'required',

        ]);
        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 401);
        }
        $res = Project::where('id', $request->id)->first();
        if(!isset($res))
        {
            return response()->json([
                'status' => false,
                'message' => 'Not existed id',
            ], 401);
        }
        $res->name = $request->name;
        $res->save();

        return response()->json([
            'status' => 200,
            'message' => 'update Project updated',
        ]);

    }

}
