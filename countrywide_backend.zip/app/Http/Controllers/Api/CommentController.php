<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Web\Controller;
use Illuminate\Http\Request;
use App\Models\Comment;
use App\Models\SubSection;
use Illuminate\Support\Facades\Validator;

class CommentController extends Controller
{
    //

    public function getAllComment4Subsection(Request $request)
    {
        $subsectionId = $request->get('subsection_id');

        if(!isset($subsectionId))
        {
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }
        
        $res = SubSection::with(['comments' => function($comment){
            return $comment->with('user')->orderBy('created_at', 'desc');
        }])->where('id', $subsectionId)->first();
        return response()->json([
            'status' => 200,
            'data' => $res ,
        ], 200);
    }

    public function getAllCommentByUser(Request $request)
    {
        $res = SubSection::with(['comments' => function($comment){
            return $comment->where('user_id', $request->user()->id)->orderBy('created_at', 'desc');
        }])
        ->get();
        return response()->json([
            'status' => 200,
            'data' => $res ,
        ], 200);
    }
    public function deleteComment(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'comment_id' => 'required',
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        $comment = Comment::where('id', $request->comment_id)->first();

        if(!isset($comment))
        {
            return response()->json([
                'status' => false,
                'message' => 'No existing the selected comment',
            ], 500);
        }


        $comment->delete();

        return response()->json([
            'status' => 200,
            'message' => 'success to delete the comment',
        ], 200);
    }

    public function updateComment(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'comment_id' => 'required',
            'comment' => 'required',
            'subsection_id' => 'required',
        ]);

        
        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        $oldComment = Comment::where('id', $request->comment_id)->first();

        if(!isset($oldComment))
        {
            return response()->json([
                'status' => false,
                'message' => 'No existing the selected comment',
            ], 500);
        }

        $oldComment->comment = $request->comment;
        $oldComment->save();

        return response()->json([
            'status' => 200,
            'message' => 'success to update the comment',
        ], 200);
    }


    public function addReply(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'comment' => 'required',
            'subsection_id' => 'required',
            'parentId' => 'required'
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        Comment::Create([
            'comment' => $request->comment,
            'subsection_id' => $request->subsection_id,
            'user_id' => $request->user()->id,
            'parent_id'=> $request->parentId,
        ]);

        return response()->json([
            'status' => 200,
            'message' => 'success to add new comment',
        ], 200);

    }

    public function addComment(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'comment' => 'required',
            'subsection_id' => 'required',
        ]);


        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        Comment::Create([
            'comment' => $request->comment,
            'subsection_id' => $request->subsection_id,
            'user_id' => $request->user()->id,
            'parent_id'=> 0,
        ]);

        return response()->json([
            'status' => 200,
            'message' => 'success to add new comment',
        ], 200);
    }
}
