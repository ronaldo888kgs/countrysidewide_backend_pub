<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Web\Controller;
use Illuminate\Http\Request;
use App\Models\Floor;
use App\Models\Unit;
use App\Models\Section;
use App\Models\SubSection;
use Illuminate\Support\Facades\Validator;

class FloorController extends Controller
{
    //

    public function getFloors(Request $request)
    {
        $res = null;
        if($request->user()->user_type != "Super")
        {
            $res = Floor::where('workspace_id', $request->user()->workspace_id)->get()->orderBy('item_order', 'asc');
        } else {
            $res = Floor::all()->orderBy('item_order', 'asc');
        }
        
        return response()->json([
            'status' => 200,
            'floors' => $res
        ], 200);
    }

    public function duplicateFloor(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'duplicate_floor_id' => 'required',
            'duplicate_to_floor_id' => 'required',
        ]);
        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        $floor = Floor::with('units.sections.subsections')->where('id', $request->duplicate_floor_id)->where('workspace_id', $request->user()->workspace_id)->first();
        $floorTarget = Floor::with('units.sections.subsections')->where('id', $request->duplicate_to_floor_id)->where('workspace_id', $request->user()->workspace_id)->first();

        //delete duplicated
        foreach($floorTarget->units as $unit)
        {
            $def_unit = Unit::where('id', $unit->id)->first();
            $def_unit->delete();
        }

        foreach($floor->units as $unit1)
        {
            // ->where('workspace_id', $request->user()->workspace_id)
            $newUnit = Unit::create(['name' => $unit1->name, 
                        'project_id' => $unit1->project_id, 
                        'floor_id' => $floorTarget->id,
                        'workspace_id' => $request->user()->workspace_id,
                        'user_id' => $request->user()->id]);
            foreach($unit1->sections as $section1)
            {

                $newSection = Section::create([
                    'name' => $section1->name, 
                    'unit_id' => $newUnit->id,
                    'user_id' => $request->user()->id,
                    'workspace_id' => $request->user()->workspace_id,
                ]);
                foreach($section1->subsections as $subsections1)
                {
                    SubSection::create([
                        'name'=> $subsections1->name,
                        'user_id' => $request->user()->id,
                        'section_id' => $newSection->id,
                        'status' => $subsections1->status,
                        'completion_status' => $subsections1->completion_status,
                        'workspace_id' => $request->user()->workspace_id,
                        'attachments', 0
                    ]);
                }
                
            }
        }

        return response()->json([
            'status' => 200,
            'message' => 'success to add new floor',
        ], 200);
    }

    public function addFloor(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'name' => 'required',
            'project_id' => 'required',
        ]);
        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        $countFloors = Floor::where('project_id', $request->project_id)->get()->count();
        $oldFloor = Floor::with('units.sections.subsections')->where('project_id', $request->project_id)->where('workspace_id', $request->user()->workspace_id)->latest('created_at')->first();
        
        $newFloor = Floor::create(['name' => $request->name, 'workspace_id' => $request->user()->workspace_id,'project_id' => $request->project_id, 'user_id' => $request->user()->id, 'item_order' => $countFloors]);


        if(isset($request->duplicate_unit))
        {
            foreach($request->duplicate_unit as $dup_unit)
            {
                $oldUnit = Unit::where('id', $dup_unit)->first();
                if($oldUnit)
                {
                    $newUnit = Unit::create(['name' => $oldUnit->name, 
                        'project_id' => $request->project_id, 
                        'floor_id' => $newFloor->id,
                        'workspace_id' => $request->user()->workspace_id,
                        'user_id' => $request->user()->id]);
                    foreach($oldUnit->sections as $section1)
                    {
    
                        $newSection = Section::create([
                            'name' => $section1->name, 
                            'unit_id' => $newUnit->id,
                            'workspace_id' => $request->user()->workspace_id,
                            'user_id' => $request->user()->id,
                            'order_in_project' => $section1->order_in_project
                        ]);
                        foreach($section1->subsections as $subsections1)
                        {
                            SubSection::create([
                                'name'=> $subsections1->name,
                                'user_id' => $request->user()->id,
                                'section_id' => $newSection->id,
                                'status' => $subsections1->completion_status == 1 ? -1 : 0,
                                'workspace_id' => $request->user()->workspace_id,
                                'completion_status' => $subsections1->completion_status,
                                'attachments', 0
                            ]);
                        }
                        
                    }
                }
            }

            
        }else{
            if($oldFloor)
            {
                 foreach($oldFloor->units as $unit1)
                {

                    $newUnit = Unit::create(['name' => "default", 
                                'project_id' => $request->project_id, 
                                'floor_id' => $newFloor->id,
                                'workspace_id' => $request->user()->workspace_id,
                                'user_id' => $request->user()->id]);
                    foreach($unit1->sections as $section1)
                    {

                        $newSection = Section::create([
                            'name' => $section1->name, 
                            'unit_id' => $newUnit->id,
                            'workspace_id' => $request->user()->workspace_id,
                            'user_id' => $request->user()->id,
                            'order_in_project' => $section1->order_in_project
                        ]);
                        foreach($section1->subsections as $subsections1)
                        {
                            SubSection::create([
                                'name'=> $subsections1->name,
                                'user_id' => $request->user()->id,
                                'section_id' => $newSection->id,
                                'status' => $subsections1->completion_status == 1 ? -1 : 0,
                                'workspace_id' => $request->user()->workspace_id,
                                'completion_status' => $subsections1->completion_status,
                                'attachments', 0
                            ]);
                        }
                        
                    }
                    break;
                }
            }
        }
        // if($oldFloor)
        // {
        //      foreach($oldFloor->units as $unit1)
        //     {

        //         $newUnit = Unit::create(['name' => "default", 
        //                     'project_id' => $request->project_id, 
        //                     'floor_id' => $newFloor->id,
        //                     'workspace_id' => $request->user()->workspace_id,
        //                     'user_id' => $request->user()->id]);
        //         foreach($unit1->sections as $section1)
        //         {

        //             $newSection = Section::create([
        //                 'name' => $section1->name, 
        //                 'unit_id' => $newUnit->id,
        //                 'workspace_id' => $request->user()->workspace_id,
        //                 'user_id' => $request->user()->id
        //             ]);
        //             foreach($section1->subsections as $subsections1)
        //             {
        //                 SubSection::create([
        //                     'name'=> $subsections1->name,
        //                     'user_id' => $request->user()->id,
        //                     'section_id' => $newSection->id,
        //                     'status' => $subsections1->status,
        //                     'workspace_id' => $request->user()->workspace_id,
        //                     'completion_status' => $subsections1->completion_status
        //                 ]);
        //             }
                    
        //         }
        //         break;
        //     }
        // }
        return response()->json([
            'status' => 200,
            'message' => 'success to add new floor',
        ], 200);
    }


    public function deleteFloor(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'id' => 'required',

        ]);
        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }
        $res = Floor::where('id', $request->id)->where('workspace_id' , $request->user()->workspace_id,)->first();
        if(!isset($res))
        {
            return response()->json([
                'status' => false,
                'message' => 'Not existed id',
            ], 500);
        }
        $res->delete();
        return response()->json([
            'status' => 200,
            'message' => 'update floor updated',
        ]);

    }


    public function updateOrders(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'orders' => 'required',
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        foreach($request->orders as $order)
        {
            $res = Floor::where('id', $order["id"])->where('workspace_id' , $request->user()->workspace_id,)->first();
            if(isset($res))
            {
                $res->item_order = $order["order"];
                $res->save();
            }
        }
        return response()->json([
            'status' => 200,
            'message' => 'update floor updated',
        ]);


    }

    public function updateFloor(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'id' => 'required',
            'name' => 'required',
            'project_id' => 'required'

        ]);
        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }
        $res = Floor::where('id', $request->id)->where('workspace_id' , $request->user()->workspace_id,)->first();
        if(!isset($res))
        {
            return response()->json([
                'status' => false,
                'message' => 'Not existed id',
            ], 401);
        }
        $res->name = $request->name;
        $res->project_id = $request->project_id;
        $res->save();

        return response()->json([
            'status' => 200,
            'message' => 'update floor updated',
        ]);

    }
}
