<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Web\Controller;
use Illuminate\Http\Request;
use App\Models\History;
use Illuminate\Support\Facades\DB;

class HistoryController extends Controller
{
    //


    public function getAllHistory(Request $request)
    {
        // $res = History::where('project_id', $request->get('project_id'))->get();

        $res = DB::table('histories')
        ->leftJoin('sub_sections', 'histories.model_id', '=', 'sub_sections.id')
        ->leftJoin('sections', 'sub_sections.section_id', '=', 'sections.id')
        // ->leftJoin('sections', 'sub_sections.section_id', '=', 'sections.id')
        ->leftJoin('units', 'sections.unit_id', '=', 'units.id')
        ->leftJoin('floors', 'units.floor_id', '=', 'floors.id')
        ->select('histories.created_at as created_date', 'histories.*', 'sub_sections.*', 'sections.*', 'units.id as unit_id', 'units.name as unit_name', 'floors.name as floor_name')
        ->where('floors.project_id',  $request->get('project_id'))->get();

        return response()->json([
            'status' => 200,
            'message' => 'success to get history',
            'projectid' => $request->get('project_id'), 
            'history' => $res
        ], 200);
        // return response()->json([
        //     'status' => 200,
        //     'message' => 'success to get history',
        // ], 200);
    }

    
}
