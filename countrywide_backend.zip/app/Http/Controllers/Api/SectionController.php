<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Web\Controller;
use Illuminate\Http\Request;
use App\Models\Section;
use App\Models\SubSection;
use App\Models\Unit;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class SectionController extends Controller
{
    //

    public function getAllSections(Request $request)
    {
        $res = null;
        if($request->user()->user_type == "Super")
            $res = Section::with('subsections')->get();
        else
            $res = Section::with('subsections')->where('workspace_id', $request->user()->workspace_id)->get();
        return response()->json([
            'status' => 200,
            'sections' => $res
        ], 200);
    }

    public function changeSectionOrders(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'orders' => 'required',
            'projectId' => 'required'
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                
                'errors' => $validateUser->errors()
            ], 500);
        }


        $units = DB::table('units')
        ->leftJoin('floors', 'floor_id', '=', 'floors.id')->where('floors.project_id', $request->projectId)->select('units.id as unit_id')->get();
        // $units = Unit::with('floor')->where('project_id', $request->projectId)->get();


        $rrrr = '';
        $sss = '';
        foreach($units as $unit)
        {
            // $fullUnit = Unit::with('sections')->where('id', $unit->id)->get();
            $sections = DB::table('sections')
            ->leftJoin('units', 'unit_id', '=', 'units.id')
            ->where('units.id', $unit->unit_id)
            ->select('sections.id as section_id', 'sections.name as section_name', 'sections.*')
            ->get();
            foreach($sections as $section)
            {
                foreach($request->orders as $order)
                {
                    $rrrr .= $order['name'];
                    $sss .= $section->section_name;
                    //name: item.label, order: index
                    if($order['name'] === $section->section_name)
                    {
                        
                        $sectionObj = Section::where('id', $section->section_id)->first();
                        $sectionObj->order_in_project = $order["order"];
                        $sectionObj->save();
                        break;
                    }
                    
                }
            }


        }

        return response()->json([
            'status' => 200,
            'message' => 'success to update orders',
            'units' => $units,
            'rrrr' => $rrrr,
            'sss' => $sss
        ], 200);

        
    }

    public function addSection(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'name' => 'required',
            'project_id' => 'required',
            'subcat_no' => 'required',
            'subsections' => 'required',
            'floors_ids' => 'required',
            'selectedCatId' => 'required'
            // 'unit_ids' => 'required',
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                
                'errors' => $validateUser->errors()
            ], 200);
        }

        

        for($i = 0 ; $i < $request->subcat_no ; $i++)
        {
            for($j = 0 ; $j < count($request->floors_ids) ; $j++)
            { 
            //    dd($request->floors_ids[$j]);
                $floor = $request->floors_ids[$j];
                // dd($floor);
               
                if(count($floor["units"]) > 0)
                {
                    // dd($floor->units);
                    for($k = 0 ; $k < count($floor["units"]) ; $k++)
                    {
                        $unitId = $floor["units"][$k];
                        $section = Section::create([
                            'name' => $request->name,   
                            'unit_id' => $unitId,
                            'workspace_id' => $request->user()->workspace_id,
                            'user_id' => $request->user()->id,
                            'order_in_project' => 0,
                            'category_id' => $request->selectedCatId
                        ]);
        
                        for($l = 0 ; $l < count($request->subsections); $l++)
                        {
                            SubSection::create([
                                'name'=> $request->subsections[$l]['name'],
                                'user_id' => $request->user()->id,
                                'section_id' => $section->id,
                                'workspace_id' => $request->user()->workspace_id,
                                'status' => $request->subsections[$l]['status'] == 1 ? -1 : 0,
                                'completion_status' => $request->subsections[$l]['status'] == 1 ? 1 : 0,
                                'attachments'=> 0,
                                'sub_category_id' => $request->subsections[$l]['id'] 

                                // 'status' => 0,
                                // 'completion_status' => 0,
                            ]);
                        }
        
                    }
                }else{
                    $defaultUnit = Unit::create(['name' => "default", 
                                                'project_id' => $request->project_id, 
                                                'floor_id' => $floor["id"],
                                                'workspace_id' => $request->user()->workspace_id,
                                                'user_id' => $request->user()->id]);
                    $section = Section::create([
                        'name' => $request->name,   
                        'unit_id' => $defaultUnit->id,
                        'workspace_id' => $request->user()->workspace_id,
                        'user_id' => $request->user()->id,
                        'order_in_project' => 0,
                        'category_id' => $request->selectedCatId
                    ]);
                                
                    for($l = 0 ; $l < count($request->subsections); $l++)
                    {
                        SubSection::create([
                            'name'=> $request->subsections[$l]['name'],
                            'user_id' => $request->user()->id,
                            'section_id' => $section->id,
                            'workspace_id' => $request->user()->workspace_id,
                            'status' => $request->subsections[$l]['status'] == 1 ? -1 : 0,
                            'completion_status' => $request->subsections[$l]['status'] == 1 ? 1 : 0,
                            'attachments'=> 0,
                            'sub_category_id' => $request->subsections[$l]['id'] 
                            // 'status' => 0,
                            // 'completion_status' => 0,
                        ]);
                    }
                }
                
            }
            
        }



       
        return response()->json([
            'status' => 200,
            'message' => 'success to add new unit',
        ], 200);
    }

}
