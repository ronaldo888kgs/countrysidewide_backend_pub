<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Web\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\TicketTemplate;
use Illuminate\Support\Facades\URL;

class TaskAssigmentController extends Controller
{
    //
}
