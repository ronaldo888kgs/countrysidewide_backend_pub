<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Web\Controller;
use Illuminate\Http\Request;
use App\Models\Project;
use App\Models\Floor;
use App\Models\Unit;
use App\Models\Section;
use App\Models\SubSection;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class UnitController extends Controller
{
    //

    public function getAllUnits(Request $request)
    {
        $res = null;
        if($request->user()->user_type != "Super")
            $res = Unit::with('floors')->where('workspace_id', $request->user()->workspace_id)->get();
        else
            $res = Unit::with('floors')->get();
        return response()->json([
            'status' => 200,
            'projects' => $res
        ], 200);
    }

    public function addUnit(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'name' => 'required',
            'project_id' => 'required',
            'floor_id' => 'required',
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        $oldUnits = Unit::where('floor_id', $request->floor_id)->first();

        $newUnit = Unit::create(['name' => $request->name, 
                        'project_id' => $request->project_id, 
                        'floor_id' => $request->floor_id,
                        'workspace_id' => $request->user()->workspace_id,
                    'user_id' => $request->user()->id]);


        if(!isset($oldUnits))
        {
            $oldUnitId = DB::table('units')
            ->leftJoin('floors', 'floor_id', '=', 'floors.id')->where('floors.project_id', $request->project_id)->select('units.id as unit_id')->first();
            $oldUnits = Unit::where('id', $oldUnitId->unit_id)->first();
        }

        if($oldUnits)
        {
            foreach($oldUnits->sections as $section1)
            {

                $newSection = Section::create([
                    'name' => $section1->name, 
                    'unit_id' => $newUnit->id,
                    'workspace_id' => $request->user()->workspace_id,
                    'user_id' => $request->user()->id,
                    'order_in_project' => $section1->order_in_project
                ]);
                foreach($section1->subsections as $subsections1)
                {
                    SubSection::create([
                        'name'=> $subsections1->name,
                        'user_id' => $request->user()->id,
                        'section_id' => $newSection->id,
                        'workspace_id' => $request->user()->workspace_id,
                        'status' => $subsections1->completion_status == 1 ? -1 : 0,
                        'completion_status' => $subsections1->completion_status,
                        'attachments', 0
                    ]);
                }
            }

            if($oldUnits->name == "default")
                $oldUnits->delete();
        }
        return response()->json([
            'status' => 200,
            'message' => 'success to add new unit',
        ], 200);
    }


    public function deleteUnit(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'id' => 'required',
            'name' => 'required',

        ]);
        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 401);
        }
        $res = Unit::where('id', $request->id)->first();
        if(!isset($res))
        {
            return response()->json([
                'status' => false,
                'message' => 'Not existed id',
            ], 401);
        }
        $res->delete();
        return response()->json([
            'status' => 200,
            'message' => 'update unit updated',
        ]);

    }

    public function updateUnit(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'id' => 'required',
            'name' => 'required',

        ]);
        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 401);
        }
        $res = Unit::where('id', $request->id)->first();
        if(!isset($res))
        {
            return response()->json([
                'status' => false,
                'message' => 'Not existed id',
            ], 401);
        }
        $res->name = $request->name;
        $res->save();

        return response()->json([
            'status' => 200,
            'message' => 'update unit updated',
        ]);

    }
}
