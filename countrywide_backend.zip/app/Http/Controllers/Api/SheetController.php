<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Web\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\Sheet;

class SheetController extends Controller
{
    //

    public function convertUploadedPdf2Png(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'file' => 'required'
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        foreach($request->file as $index => $file)
        {
            $imagick = new Imagick();

            $filename = time().'_'.$index.'_.pdf';
            

        }
    }
    public function addNewSheetAsDraft(Request $request)
    {
        $validateUser = Validator::make($request->all(), 
        [
            'project_id' => 'required',
            'vs_id' => 'required',
        ]);

        if($validateUser->fails()){
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
            ], 500);
        }

        $newSheet = Sheet::create([
            'version_set_id' => $request->vs_id,
            'project_id' => $request->project_id,
            'workspace_id' => $request->user()->workspace_id,
            'created_by' => $request->user()->id,
        ]);

        return response()->json([
            'status' => 200,
            'resId' => $newSheet->id,
        ], 200);


    }
}
