<?php

namespace App\Http\Controllers\Web;

use Illuminate\Http\Request;

class AreaController extends Controller
{
    //
}
