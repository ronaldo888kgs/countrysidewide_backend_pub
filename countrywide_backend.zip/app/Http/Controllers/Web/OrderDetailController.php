<?php

namespace App\Http\Controllers\Web;

use Illuminate\Http\Request;

class OrderDetailController extends Controller
{
    //
}
