<?php

namespace App\Http\Controllers\Web;

use Illuminate\Http\Request;

class AppartmentController extends Controller
{
    //
}
